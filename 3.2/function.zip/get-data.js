const jwt = require('jsonwebtoken');

exports.handler = async function (event, context) {

}